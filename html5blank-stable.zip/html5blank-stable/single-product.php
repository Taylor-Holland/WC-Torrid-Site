<?php
/**
 * @package WordPress
 */
get_header(); ?>

<main class="main" role="main">

<?php if (have_posts()): ?>

    <?php while (have_posts()): the_post(); ?>

        <article <?php post_class() ?> id="post-<?php the_ID(); ?>">
            <h1><?php the_title(); ?></h1>

            <div class="postcontent">
                <?php the_content(__('(continue...)')); ?>
                <?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
            </div><!--/postcontent-->
            
        </article><!--/post-->

    <?php endwhile; ?>

<?php else: ?>

    <?php get_template_part('notfound'); ?>

<?php endif; ?>

</main>

<?php get_sidebar(); ?>

<?php get_footer(); ?>