<?php
/**
 * Template Name: Test
 */
get_header(); ?>

<main>

	<!-- section -->


		<div class="banner">
			<img src="<?php the_field('banner'); ?>" />

				<div class="black-button">
					<a href="<?php the_field('button_link'); ?>">
						<?php the_field('button_text'); ?>
					</a>

				</div>
		</div>

		<br><br>

		<section>
				<div class="WC-features">
					<div class="feature">
						<div class="features-button">
							<a href="<?php the_field('feature_button'); ?>">
								<?php the_field('feature_button_text'); ?>
							</a>
						</div>
						<img src="<?php the_field('feature1'); ?>"/>
						</div>


						<div class="feature">
								<div class="features-button">
									<a href="<?php the_field('feature_button2'); ?>">
										<?php the_field('feature_button_text2'); ?>
									</a>

								 </div>
						 <img src="<?php the_field('feature2'); ?>"/>
							</div>


							<div class="feature">
									<div class="features-button">
										<a href="<?php the_field('feature_button3'); ?>">
											<?php the_field('feature_button_text3'); ?>
										</a>
									 </div>
								<img src="<?php the_field('feature3'); ?>"/>
								</div>

				</div>
			</section>
</main>

<?php get_footer(); ?>
