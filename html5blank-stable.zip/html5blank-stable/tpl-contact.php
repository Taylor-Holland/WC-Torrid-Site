<?php
/**
 * Template Name: Contact
 */
get_header(); ?>

	<main role="main">
		<!-- section -->
		<section>

			    <div class="contact-container">
			      <h4><?php the_field('contact_title'); ?></h4>
			      <div class="contact-column">
			        <p>
			          <?php the_field('how_can_we_help'); ?>
			          <br>
			          <?php the_field('contact_us'); ?>
			          <br>
			          <?php the_field('order_status'); ?>
			          <br>
			          <?php the_field('returns'); ?>
			          <br>
			          <?php the_field('international'); ?>
			          <br><br>

			          <?php the_field('helpful_links'); ?>
			          <br>
			          <?php the_field('shipping'); ?>
			          <br>
			          <?php the_field('torrid_catalog'); ?>
			          <br>
			          <?php the_field('size_chart'); ?>
			          <br>
			          <?php the_field('gift_cards'); ?>
			          <br><br>

			          <?php the_field('my_accounts'); ?>
			          <br>
			          <?php the_field('sign_in__view_accounts'); ?>
			          <br>
			          <?php the_field('torrid_insider_rewards'); ?>
			          <br>
			          <?php the_field('view_my_points'); ?>
			          <br>
			          <?php the_field('torrid_insider_credit_card'); ?>
			          <br>
			        </p>
			      </div>
			      <div class="contact-column">
			          <?php the_field('frequently_asked_questions'); ?>
			<br><br>
			<?php the_field('how_do_i_find_a_store_near_me'); ?>
			<br><br>
			<?php the_field('how_do_i_return_an_item_i_purchased'); ?>
			<br><br>
			<?php the_field('ive_forgotten_my_password_how_do_i_get_a_new_one'); ?>
			<br><br>
			<?php the_field('what_payment_types_do_you_accept'); ?>
			<br><br>

			<?php the_field('more_faqs'); ?>
			<br><br>
			<?php the_field('still_need_help'); ?>
			<br>
			<?php the_field('email_us'); ?>
			<br><br>
			<?php the_field('number_us'); ?>
			<br>
			<?php the_field('number_canada'); ?>
			<br>
			<?php the_field('number_international'); ?>
			<br><br>
			<?php the_field('customer_service_phone'); ?>
			<br>
			<?php the_field('mon_-_fri'); ?>
			<br>
			<?php the_field('sat'); ?>
			<br>
			<?php the_field('sun'); ?>
			</p>
			      </div>
			      <div class="contact-column">
							<?php the_field('orders_title'); ?>
			        <br><br>
							<?php the_field('track_order_online'); ?>

			<br><br>
			<?php the_field('shipping_title'); ?>

			<br>
			<?php the_field('standard'); ?>
			<br>
			<?php the_field('business_days'); ?>
			<br>
			<?php the_field('express'); ?>
			<br>
			<?php the_field('overnight'); ?>
			<br><br>
			<?php the_field('shipping_rates'); ?>
			<br><br>
			<?php the_field('returns_and_exchanges'); ?>
			<br>
			<?php the_field('returns_by_mail'); ?>
			<br>
			<?php the_field('return_by_store'); ?>
			<br><br>
			<?php the_field('size_fit_guide'); ?>
			<br>
			<?php the_field('chart'); ?>
			<br><br>
			<?php the_field('tcard'); ?>
			<br>
			<?php the_field('apply_online'); ?>
			<br>
			<?php the_field('pay_bill'); ?>
			<br><br>
			<?php the_field('t_insider'); ?>
			<br>
			<?php the_field('benefits'); ?>
			<br>
			<?php the_field('sign'); ?>


			      </div>
			    </div>


		</section>
		<!-- /section -->
	</main>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
