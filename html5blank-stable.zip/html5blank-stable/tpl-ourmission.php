<?php
/**
 * Template Name: Our Mission
 */
get_header(); ?>

	<main role="main">
		<!-- section -->
		<section>

		<div class="mission-title">
		   <h4><?php the_title(); ?></h4>
		  </div>
		  <br>
		  <div class="mission-container">
		  <div class="our-mission-statement">
		   	<?php the_field('mission_statement'); ?>
		  </div>
		  <br>
		    <div class="community-container">
		      <img src="<?php the_field('community_image_1'); ?> " alt="<?php the_field('community_image_alt_text1'); ?>">
		      <img src="<?php the_field('community_image_2'); ?> " alt="<?php the_field('community_image_alt_text2'); ?>">
		      <img src="<?php the_field('community_image_3'); ?> " alt="<?php the_field('community_image_alt_text3'); ?>">
		      <img src="<?php the_field('community_image_4'); ?> " alt="<?php the_field('community_image_alt_text4'); ?>">
		    </div>
		<div class="blog-post-title">
		  <p><?php the_field('blog_post_title'); ?></p>
		</div>
		<div class="blog-pic-container">
		  <img src="<?php the_field('blogpic5'); ?> " alt="<?php the_field('blogpic1_alt_text5'); ?>">
		    <img src="<?php the_field('blogpic2');  ?>" alt="<?php the_field('blogpic1_alt_text2'); ?>">
		      <img src="<?php the_field('blogpic3');  ?>" alt="<?php the_field('blogpic1_alt_text3'); ?>">
		        <img src="<?php the_field('blogpic4');  ?>" alt="<?php the_field('blogpic1_alt_text4'); ?>">
		          <img src="<?php the_field('blogpic6');  ?>" alt="<?php the_field('blogpic1_alt_text6'); ?>">
		            <img src="<?php the_field('blogpic1'); ?>" alt="<?php the_field('blogpic1_alt_text'); ?>">
		              <img src="<?php the_field('blogpic7');  ?>" alt="<?php the_field('blogpic1_alt_text7'); ?>">
		                <img src="<?php the_field('blogpic8');  ?>" alt="<?php the_field('blogpic1_alt_text8'); ?>">
		                  <img src="<?php the_field('blogpic9');  ?>" alt="<?php the_field('blogpic1_alt_text9'); ?>">
		                    <img src="<?php the_field('blogpic10');  ?>" alt="<?php the_field('blogpic1_alt_text10'); ?>">
		        </div>
		  </div>
		</section>
		<!-- /section -->
	</main>

<?php get_footer(); ?>
